package ex19;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;

public class ServerExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ServerSocketChannel serverSocketChannel = null;
		try {
			//서버소켓채널 및 포트5001 생성


			
			while(true) {
				System.out.println( "[연결 기다림]");
				//서버소켓 accept() 클라이언트가 연결을 요청하기전까지 블로킹, 요청하면 클라이언트와 통신할 Socket을 만들고 리턴
				SocketChannel socketChannel = serverSocketChannel.accept();
				InetSocketAddress isa = (InetSocketAddress) socketChannel.getRemoteAddress();
				System.out.println("[연결 수락함] " + isa.getHostName());
				
				
				ByteBuffer byteBuffer = null;
				Charset charset = Charset.forName("UTF-8");
				//클라이언트가 보낸 "Hello Server" 데이터 받고 출력
				
				
				
				
				System.out.println("[데이터 받기 성공]:"+ message);
				
				//서버가 "Hello Client"를 클라이언트로 전송

				
				System.out.println("[데이터 보내기 성공]");
				
				
				
			}
		} catch(Exception e) {}
		
		if(serverSocketChannel.isOpen()) {
			try {
				serverSocketChannel.close();
			} catch (IOException e1) {}
		}
	}

}
